import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import simRoutes from './routes/sim.routes.js';
import employeeRoutes from './routes/employee.routes.js';
import authRoutes from './routes/auth.js';



// Charger les variables d'environnement
dotenv.config();

const app = express();
const port = process.env.PORT || 5000;

// Middleware pour CORS
app.use(cors({
  origin: 'http://localhost:4200',
}));

// Middleware pour parser le JSON
app.use(express.json());

// Connexion à MongoDB
mongoose.connect('mongodb+srv://abidimenel4:KF1VGc4oz83JciYt@cluster0.wx1zn.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
  .then(() => console.log('Database connected'))
  .catch((error) => console.error('Database connection error:', error));

// Routes
app.use('/api/sims', simRoutes);
app.use('/api/employees', employeeRoutes);
app.use('/api/auth', authRoutes);

// Lancer le serveur
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});


