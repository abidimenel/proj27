import Sim from '../models/sim.model.js';
import Employee from '../models/employee.model.js';

// Récupérer toutes les SIMs
export const getAllSims = async (req, res) => {
  try {
    const sims = await Sim.find();
    res.status(200).json(sims);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Attribuer un numéro de téléphone à une SIM
export const assignPhoneNumberToSim = async (req, res) => {
  try {
    const { serialNumber, phoneNumber } = req.body;
    const sim = await Sim.findOne({ serialNumber });
    
    if (!sim) {
      return res.status(404).json({ message: 'SIM non trouvée.' });
    }

    sim.phoneNumber = phoneNumber;
    await sim.save();

    res.status(200).json({ message: 'Numéro de téléphone attribué à la SIM.', sim });
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de l\'attribution.', error });
  }
};

// Attribuer une SIM à un employé
export const assignSimToEmployee = async (req, res) => {
  try {
    const { employeeId, serialNumber, forfait, forfaitInternet } = req.body;

    const employee = await Employee.findById(employeeId);
    if (!employee) {
      return res.status(404).json({ message: 'Employé non trouvé.' });
    }

    const sim = await Sim.findOne({ serialNumber });
    if (!sim) {
      return res.status(404).json({ message: 'SIM non trouvée.' });
    }

    employee.simSerialNumber = serialNumber;
    employee.forfait = forfait;
    employee.forfaitInternet = forfaitInternet;
    employee.dateAttribution = new Date();
    await employee.save();

    res.status(200).json({ message: 'SIM attribuée à l\'employé.', employee });
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de l\'attribution.', error });
  }
};
