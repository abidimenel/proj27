import Employee from '../models/employee.model.js';
import Sim from '../models/sim.model.js';

// Récupérer tous les employés
export const getAllEmployees = async (req, res) => {
  try {
    const employees = await Employee.find();
    res.status(200).json(employees);
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de la récupération des employés' });
  }
};

// Créer un nouvel employé
export const createEmployee = async (req, res) => {
  const newEmployee = new Employee(req.body);
  try {
    await newEmployee.save();
    res.status(201).json(newEmployee);
  } catch (error) {
    res.status(400).json({ message: 'Erreur lors de la création de l\'employé' });
  }
};
