import express from 'express';
import { getAllSims, assignPhoneNumberToSim, assignSimToEmployee } from '../controllers/sim.controller.js';

const router = express.Router();

// Récupérer toutes les SIMs
router.get('/', getAllSims); // GET http://localhost:5000/api/sims

// Attribuer un numéro de téléphone à une SIM
router.post('/assign-phone-number', assignPhoneNumberToSim); // POST http://localhost:5000/api/sims/assign-phone-number

// Attribuer une SIM à un employé
router.post('/assign-sim', assignSimToEmployee); // POST http://localhost:5000/api/sims/assign-sim

export default router;
