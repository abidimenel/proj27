import express from 'express';
import { getAllEmployees, createEmployee } from '../controllers/employee.controller.js';

const router = express.Router();

// Récupérer tous les employés
router.get('/', getAllEmployees);

// Créer un nouvel employé
router.post('/', createEmployee);

export default router;
