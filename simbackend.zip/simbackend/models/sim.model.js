import mongoose from 'mongoose';

const simSchema = new mongoose.Schema({
  serialNumber: { type: String, required: true, unique: true },
  forfait: { type: String, required: true },
  forfaitInternet: { type: String, required: true },
  assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee', default: null },
  assignedDate: { type: Date, default: null },
  phoneNumber: { type: String, default: null },
  addedDate: { type: Date, default: Date.now },
});

const Sim = mongoose.model('Sim', simSchema);

export default Sim;
