import mongoose from 'mongoose';

const employeeSchema = new mongoose.Schema({
  name: { type: String, required: true },
  cin: { type: String, required: true, unique: true },
  position: { type: String },
  department: { type: String },
  phoneNumber: { type: String, default: 'Pas de numéro' },
  internetPlan: { type: String },
  simSerialNumber: { type: String, default: 'Aucune SIM' },
  forfait: { type: String },
  forfaitInternet: { type: String },
  dateAttribution: { type: Date, default: null },
  sim: { type: mongoose.Schema.Types.ObjectId, ref: 'Sim', default: null },
});

const Employee = mongoose.model('Employee', employeeSchema);

export default Employee;
