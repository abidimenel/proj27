import { Component } from '@angular/core';

@Component({
  selector: 'app-numbers-list',
  templateUrl: './numbers-list.component.html',
  styleUrls: ['./numbers-list.component.css']
})
export class NumbersListComponent {
 
  assignedNumbers: { number: string, employee: string }[] = [
    { number: '1004', employee: 'John Doe' }
  ];
}
