import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { EmployeeService } from './employee.service';

describe('EmployeeService', () => {
  let service: EmployeeService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [EmployeeService],
    });

    service = TestBed.inject(EmployeeService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should send email and return success response', () => {
    const mockEmailData = {
      cin: '12345678',
      poste: 'manager',
      service: 'IT',
      forfait: 'Forfait A',
      forfaitInternet: '15Go',
      crnNumber: 'CRN12345',
    };

    const mockResponse = { success: true, message: 'Email sent successfully' };

    service.sendEmail(mockEmailData).subscribe((response) => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpMock.expectOne('https://your-email-api.com/send');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({
      to: 'societe@exemple.com',
      subject: 'Attribution de numéro et forfait',
      body: `
        Voici les détails de l'attribution :
        CIN: ${mockEmailData.cin}
        Poste: ${mockEmailData.poste}
        Service: ${mockEmailData.service}
        Forfait: ${mockEmailData.forfait}
        Forfait Internet: ${mockEmailData.forfaitInternet}
        CRN Number: ${mockEmailData.crnNumber}
      `,
    });

    req.flush(mockResponse);
  });
});
