import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';  // Ajout de catchError pour la gestion des erreurs
import { of } from 'rxjs';  // Pour retourner une valeur par défaut en cas d'erreur

@Injectable({
  providedIn: 'root'
})
export class SimService {
  private apiUrl = 'http://localhost:5000/api';  // URL de votre backend local pour SIMs et Employees
  
  constructor(private http: HttpClient) { }

  // Récupérer toutes les SIMs
  getAllSims(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/sims`).pipe(
      catchError(error => {
        console.error('Erreur lors de la récupération des SIMs', error);
        return of([]);  // Retourner un tableau vide en cas d'erreur
      })
    );
  }

  // Ajouter une nouvelle SIM
  createSim(simData: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json', // Assurez-vous que le type de contenu est bien défini
      }),
    };

    return this.http.post<any>(`${this.apiUrl}/sims`, simData, httpOptions).pipe(
      catchError(error => {
        console.error('Erreur lors de l\'ajout de la SIM', error);
        return of(null);  // Retourner null en cas d'erreur
      })
    );
  }

  // Attribuer une SIM à un employé
  assignSim(simData: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json', // Assurez-vous que le type de contenu est bien défini
      }),
    };

    return this.http.post<any>(`${this.apiUrl}/sims/assign`, simData, httpOptions).pipe(
      catchError(error => {
        console.error('Erreur lors de l\'attribution de la SIM', error);
        return of(null);  // Retourner null en cas d'erreur
      })
    );
  }
}
