import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(): boolean {
    const user = this.authService.getLoggedInUser();

    if (user) {
      return true; // L'utilisateur est connecté, accès autorisé
    } else {
      // L'utilisateur n'est pas connecté, redirection vers la page de login
      this.router.navigate(['/login']);
      return false;
    }
  }
}