import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SimService } from '../sim.service';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-assign-sim',
  templateUrl: './assign-sim.component.html',
  styleUrls: ['./assign-sim.component.css']
})
export class AssignSimComponent implements OnInit {
  assignForm: FormGroup;  
  forfait: string = '30 DT';  
  forfaitInternet: string = '15 Go';  
  detailsVisible: boolean = false; 

  constructor(private fb: FormBuilder) {
    this.assignForm = this.fb.group({
      nom: ['', Validators.required],
      cin: ['', Validators.required],
      poste: ['', Validators.required],
      service: ['', Validators.required],
      serialNumber: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    // Additional logic if needed
  }

  onSubmit(): void {
    if (this.assignForm.valid) {
      this.detailsVisible = true;
    }
  }

  copyToClipboard(): void {
    const dataToCopy = `Nom: ${this.assignForm.value.nom}
CIN: ${this.assignForm.value.cin}
Poste: ${this.assignForm.value.poste}
Service: ${this.assignForm.value.service}
Forfait: ${this.forfait}
Forfait Internet: ${this.forfaitInternet}
Serial Number: ${this.assignForm.value.serialNumber}`;

    navigator.clipboard.writeText(dataToCopy).then(() => {
      alert('Les données ont été copiées dans le presse-papiers');
    }).catch((error) => {
      console.error('Erreur lors de la copie dans le presse-papiers', error);
    });
  }

  closeModal(): void {
    this.detailsVisible = false;
  }

  onPosteChange(): void {
    const poste = this.assignForm.get('poste')?.value;
    if (poste === 'technicien') {
      this.forfait = '30 DT';
      this.forfaitInternet = '15 Go';
    } else if (poste === 'specialiste') {
      this.forfait = '50 DT';
      this.forfaitInternet = '30 Go';
    } else if (poste === 'manager') {
      this.forfait = '70 DT';
      this.forfaitInternet = '30 Go';
    } else if (poste === 'directeur') {
      this.forfait = '100 DT';
      this.forfaitInternet = '30 Go';
    }
  }

  onSerialNumberInput(event: Event): void {
    const input = event.target as HTMLInputElement;
    console.log(input.value);
  }
}
