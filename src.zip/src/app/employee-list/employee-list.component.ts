import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  employees: any[] = [];
  filteredEmployees: any[] = [];
  searchQuery: string = '';
  isFilterMenuOpen: boolean = false;

  constructor() {}

  ngOnInit(): void {
    this.loadEmployees();
  }

  // Load sample employee data
  loadEmployees(): void {
    this.employees = [
      {
        name: 'John Doe',
        cin: '12345678',
        position: 'Manager',
        department: 'HR',
        sim: { serialNumber: 'SIM001' },
        phoneNumber: '987654321',
        simAssignedDate: new Date('2023-01-15')
      },
      {
        name: 'Jane Smith',
        cin: '87654321',
        position: 'Developer',
        department: 'IT',
        sim: null,
        phoneNumber: '',
        simAssignedDate: null
      },
      {
        name: 'Alice Johnson',
        cin: '11223344',
        position: 'Designer',
        department: 'Marketing',
        sim: { serialNumber: 'SIM002' },
        phoneNumber: '123456789',
        simAssignedDate: new Date('2024-06-01')
      }
    ];

    this.filteredEmployees = [...this.employees]; // Initialize filtered list
  }

  // Filter employees based on search query
  filterEmployees(): void {
    this.filteredEmployees = this.employees.filter(employee => 
      employee.name.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
      employee.cin.includes(this.searchQuery) ||
      employee.position.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
      employee.department.toLowerCase().includes(this.searchQuery.toLowerCase())
    );
  }

  // Toggle filter menu visibility
  toggleFilterMenu(): void {
    this.isFilterMenuOpen = !this.isFilterMenuOpen;
  }

  // Apply specific filter options
  setFilterOption(option: string): void {
    this.isFilterMenuOpen = false;

    if (option === 'withNumber') {
      this.filteredEmployees = this.employees.filter(employee => employee.sim);
    } else if (option === 'withoutNumber') {
      this.filteredEmployees = this.employees.filter(employee => !employee.sim);
    }
  }
}
