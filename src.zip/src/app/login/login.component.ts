import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
})
export class LoginComponent {
  email: string = '';
  password: string = '';
  errorMessage: string = '';
  isSubmitting: boolean = false;

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit() {
    this.isSubmitting = true;
    this.errorMessage = ''; // Réinitialise les messages d'erreur avant chaque soumission

    this.authService.login(this.email, this.password).subscribe(
      (response: { token: string; }) => {
        // Stocke le token dans localStorage
        localStorage.setItem('userToken', response.token);
        console.log('Connexion réussie:', response.token);

        // Redirection vers la page d'accueil
        this.router.navigate(['/home-page']);

        // Réinitialise l'état de soumission
        this.isSubmitting = false;
      },
      (error: { error: { message: string; }; }) => {
        // Affiche un message d'erreur si la connexion échoue
        this.errorMessage = error.error.message || 'Email ou mot de passe incorrect.';
        console.error('Erreur lors de la connexion:', this.errorMessage);

        // Réinitialise l'état de soumission
        this.isSubmitting = false;
      }
    );
  }
}
